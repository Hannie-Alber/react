function Display({count}){
    return <div>The current value is {count}</div>;
}
export default Display;